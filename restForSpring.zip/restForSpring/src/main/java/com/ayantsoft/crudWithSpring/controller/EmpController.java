package com.ayantsoft.crudWithSpring.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ayantsoft.crudWithSpring.service.EmpService;
import com.ayantsoft.hibernate.pojo.Emp;


@RestController
public class EmpController {

	@Autowired
	private EmpService empService;
	
	 @RequestMapping("/")  
	    public ModelAndView welcome() {  
	   /*  ModelAndView mv= new ModelAndView(); 
	     mv.setViewName("home");
		 return mv;*/
		 
		 ModelAndView mv=new ModelAndView();
		 mv.setViewName("home");
		 return mv;
		}  
	
	 
	 @RequestMapping(value={"updateEmp/{id}"},method={RequestMethod.GET})  
	    public ResponseEntity<Emp> getEmpForUpdate(@PathVariable("id") Integer id) {  
	     Emp e=null;
	     HttpStatus httpStatus = null;
	     e=empService.getEmpByIdService(id);
	     if(e!=null){
	     httpStatus = HttpStatus.OK;
	     e.getAddress().setEmps(null);
	     }
		 return new ResponseEntity<Emp>(e,httpStatus); 
		}  
	
	 
}
