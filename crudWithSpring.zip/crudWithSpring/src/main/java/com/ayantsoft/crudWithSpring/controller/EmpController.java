package com.ayantsoft.crudWithSpring.controller;


import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.ayantsoft.crudWithSpring.service.EmpService;
import com.ayantsoft.hibernate.pojo.Address;
import com.ayantsoft.hibernate.pojo.Emp;
import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

@Controller
public class EmpController {

	@Autowired
	private EmpService empService;
	
	 @RequestMapping("/")  
	    public ModelAndView welcome() {  
	  	 
		 ModelAndView mv=new ModelAndView();
		 
		 
		
		 mv.setViewName("home");
		 return mv;
		}  
	
	
	 @RequestMapping("/back")  
	    public ModelAndView back() {  
	     ModelAndView mv= new ModelAndView(); 
	     mv.setViewName("home");
		 return mv;
		} 
	 
	 @RequestMapping("/test")  
	    public Integer test() {  
	    // ModelAndView mv= new ModelAndView(); 
	     
		 return 10;
		} 
	 
	 /*@RequestMapping(value={"/getEmpRegPage"},method={RequestMethod.GET})  
	 */
	 	@RequestMapping(value={"/getEmpRegPage"},method={RequestMethod.GET})
	 public ModelAndView getEmpRegPage() {  
	 		
	     ModelAndView mv= new ModelAndView(); 
	     
	     Emp emp=new Emp();
	     Address add=new Address();
	     emp.setAddress(add);
	     
	     
	     mv.addObject("emp",emp);
	     mv.setViewName("EmpReg");
		 return mv;
		}  
	 
	 @RequestMapping(value={"/saveEmp"},method={RequestMethod.POST})  
	    public ModelAndView saveEmp(@ModelAttribute ("emp")Emp emp) {  
	     ModelAndView mv= new ModelAndView(); 
	     empService.insertEmpService(emp);
	     mv.setViewName("home");
		 return mv;
		}  
	 
	 @RequestMapping(value={"/ViewEmp"},method={RequestMethod.GET})  
	    public ModelAndView saveEmp() {  
	     ModelAndView mv= new ModelAndView(); 
	     List<Emp> emp=empService.getAllEmpService();
	   
	     
	     mv.addObject("emp",emp);
	     mv.setViewName("EmpView");
		 return mv;
		} 
	 
	 @RequestMapping(value={"updateEmp"},method={RequestMethod.GET})  
	    public ModelAndView getEmpForUpdate(@RequestParam Integer id) {  
	     ModelAndView mv= new ModelAndView(); 
	     Emp e=null;
	    e=empService.getEmpByIdService(id);
	   /*  RestTemplate restTemplate = new RestTemplate();
	     String url = "http://localhost:8080/restForSpring/updateEmp";
	     e=restTemplate.getForObject(url+"/"+id, Emp.class);     
	   */  mv.addObject("emp",e);
	     mv.setViewName("viewUpdate");
		 return mv;
		}  
	 
	 @RequestMapping(value={"saveUpdatedEmp"},method={RequestMethod.POST})  
	    public ModelAndView saveUpdatedEmp(@ModelAttribute ("emp")Emp emp) {  
	     ModelAndView mv= new ModelAndView(); 
	      empService.updateEmpService(emp);
	     mv.setViewName("home");
		 return mv;
		}  
	 @RequestMapping(value={"pdf"},method={RequestMethod.GET})  
	    public void pdf(HttpServletRequest request, HttpServletResponse response) {  
	 
	  response.setContentType("application/pdf");
      //Get the output stream for writing PDF object        
      OutputStream out=null;
	try {
		out = response.getOutputStream();
	 
		
		 List<Emp> emp=empService.getAllEmpService();
		   
		
         Document document = new Document();
           //Basic PDF Creation inside servlet 
          PdfWriter.getInstance(document, out);
          document.open();
          Paragraph p=  new Paragraph("                       User Information ");
          document.add(p);
          Paragraph pBlank=  new Paragraph("                     ");
          document.add(pBlank);
          
          
          PdfPTable table = new PdfPTable(3); // 3 columns.
          PdfPCell cell1 = new PdfPCell(new Paragraph("Name"));
          PdfPCell cell2 = new PdfPCell(new Paragraph("Password"));
          PdfPCell cell3 = new PdfPCell(new Paragraph("Email"));
          
         
          table.addCell(cell1);
          table.addCell(cell2);
          table.addCell(cell3);
          
          
         
         
        
          
          for(Emp e:emp){
        	  
        	  PdfPCell  cellName = new PdfPCell(new Phrase(e.getName()));
        	  table.addCell(cellName);
        	  PdfPCell  cellPass = new PdfPCell(new Phrase(e.getPassword()));
        	  table.addCell(cellPass);
        	  PdfPCell  cellEmail = new PdfPCell(new Phrase(e.getEmail()));
        	  table.addCell(cellEmail);
        	  
          }
          
          document.add(table);
          
         /* document.add(new Paragraph("Tutorial to Generate PDF using Servlet"));
          document.add(new Paragraph("PDF Created Using Servlet, iText Example Works"));
         */ document.close();
     }catch(Exception ex){}
      }
	 
}
