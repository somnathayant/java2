package com.ayantsoft.crudWithSpring.controller;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;


import test.config.TestBeanConfig;

@WebAppConfiguration 
@RunWith(SpringJUnit4ClassRunner.class) 
@ContextConfiguration(classes = {TestBeanConfig.class}) 
public class EmpControllerTest {

	/*@Autowired 
	private EmpController empController; 
	*/
	 
	 @Test public void emp_Controller_Test() { 
		// Integer i=empController.test();
		 Integer i=10;
		assertTrue( i> 0);
	}
	
	
}
