package test.config;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.ayantsoft.crudWithSpring")

public class TestBeanConfig {

}
